package demo;

import org.apache.poi.openxml4j.opc.PackagePart;
import org.apache.poi.poifs.crypt.Decryptor;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.crypt.EncryptionMode;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class WorkbookProtectorTest {
    @TempDir Path dir;
    private static final char[] PASSWORD = "Demo-only-9x!73Ab".toCharArray();
    private static final WorkbookProtector.ExportIdentity IDENTITY = new WorkbookProtector.ExportIdentity("测试提取人", "TEST-001");
    private static final String TEXT = ExcelWatermarkApp.composeWatermark("内部数据 · 禁止外传", "测试提取人", "TEST-001", false);

    @Test void allSixIdentityOptionsAreIndependent() throws Exception {
        Path source = dir.resolve("six-options-source.xlsx");
        try (XSSFWorkbook book = new XSSFWorkbook()) {
            var sheet = book.createSheet("选项测试");
            sheet.setColumnWidth(0, 20 * 256);
            sheet.createRow(0).createCell(0).setCellValue("原始数据");
            try (OutputStream out = Files.newOutputStream(source)) { book.write(out); }
        }
        for (int mask = 0; mask < 64; mask++) {
            boolean showExtractor = (mask & 1) != 0, showApproval = (mask & 2) != 0;
            boolean hideExtractor = (mask & 4) != 0, hideApproval = (mask & 8) != 0;
            boolean propertyExtractor = (mask & 16) != 0, propertyApproval = (mask & 32) != 0;
            var identity = new WorkbookProtector.ExportIdentity("测试提取人", "TEST-001",
                    hideExtractor, hideApproval, propertyExtractor, propertyApproval);
            String visible = ExcelWatermarkApp.composeWatermark("内部数据", identity.extractor(), identity.approvalNumber(),
                    showExtractor, showApproval);
            assertEquals(showExtractor, visible.contains(identity.extractor()));
            assertEquals(showApproval, visible.contains(identity.approvalNumber()));
            Path output = dir.resolve("options-" + mask + ".xlsx");
            WorkbookProtector.protect(source, output, visible, PASSWORD.clone(), 82, identity);
            try (POIFSFileSystem fs = new POIFSFileSystem(output.toFile(), true)) {
                Decryptor decryptor = Decryptor.getInstance(new EncryptionInfo(fs));
                assertTrue(decryptor.verifyPassword(new String(PASSWORD)));
                try (InputStream in = decryptor.getDataStream(fs); XSSFWorkbook book = new XSSFWorkbook(in)) {
                    var properties = book.getProperties().getCustomProperties();
                    assertEquals(propertyExtractor, properties.getProperty("提取人") != null);
                    assertEquals(propertyApproval, properties.getProperty("审批编号") != null);
                    if (propertyExtractor) assertEquals(identity.extractor(), properties.getProperty("提取人").getLpwstr());
                    if (propertyApproval) assertEquals(identity.approvalNumber(), properties.getProperty("审批编号").getLpwstr());
                    var sheet = book.getSheetAt(0);
                    assertEquals("原始数据", sheet.getRow(0).getCell(0).getStringCellValue());
                    assertEquals(showExtractor, sheet.getOddFooter().getCenter().contains(identity.extractor()));
                    assertEquals(showApproval, sheet.getOddFooter().getCenter().contains(identity.approvalNumber()));
                    validateTransparentIdentity(sheet, identity, (hideExtractor ? 1 : 0) + (hideApproval ? 1 : 0));
                    PackagePart part = sheet.getPackagePart();
                    PackagePart background = part.getRelatedPart(part.getRelationship(sheet.getCTWorksheet().getPicture().getId()));
                    try (InputStream image = background.getInputStream()) {
                        assertArrayEquals(WorkbookProtector.watermarkPng(visible, 82), image.readAllBytes());
                    }
                }
            }
        }
    }

    @Test void extractorVisibleAndHiddenWatermarksCanBeSelectedIndependently() throws Exception {
        assertEquals("内部数据\n测试提取人\nTEST-001",
                ExcelWatermarkApp.composeWatermark("内部数据", IDENTITY.extractor(), IDENTITY.approvalNumber()));
        assertTrue(IDENTITY.hiddenExtractor());
        assertDoesNotThrow(() -> ExcelWatermarkApp.composeWatermark("一\n二\n三", "姓名", "编号", false));
        assertThrows(IllegalArgumentException.class,
                () -> ExcelWatermarkApp.composeWatermark("一\n二\n三", "姓名", "编号", true));
        Path source = fixture("checkbox-source.xlsx");
        for (boolean show : new boolean[]{true, false}) {
            for (boolean hidden : new boolean[]{true, false}) {
                var identity = new WorkbookProtector.ExportIdentity(IDENTITY.extractor(), IDENTITY.approvalNumber(), hidden);
                String visible = ExcelWatermarkApp.composeWatermark("内部数据", identity.extractor(), identity.approvalNumber(), show);
                assertEquals(show ? "内部数据\n测试提取人\nTEST-001" : "内部数据\nTEST-001", visible);
                Path output = dir.resolve("checkbox-" + show + "-" + hidden + ".xlsx");
                WorkbookProtector.protect(source, output, visible, PASSWORD.clone(), 82, identity);
                try (POIFSFileSystem fs = new POIFSFileSystem(output.toFile(), true)) {
                    Decryptor decryptor = Decryptor.getInstance(new EncryptionInfo(fs));
                    assertTrue(decryptor.verifyPassword(new String(PASSWORD)));
                    try (InputStream in = decryptor.getDataStream(fs); XSSFWorkbook book = new XSSFWorkbook(in)) {
                        assertEquals(identity.extractor(), book.getProperties().getCustomProperties().getProperty("提取人").getLpwstr());
                        assertEquals(identity.approvalNumber(), book.getProperties().getCustomProperties().getProperty("审批编号").getLpwstr());
                        for (int index = 0; index < book.getNumberOfSheets(); index++) {
                            XSSFSheet sheet = book.getSheetAt(index);
                            validateImageRelations(sheet);
                            validateTransparentIdentity(sheet, identity, hidden ? 2 : 1);
                            assertEquals(show, sheet.getOddFooter().getCenter().contains(identity.extractor()));
                            assertTrue(sheet.getOddFooter().getCenter().contains(identity.approvalNumber()));
                            PackagePart part = sheet.getPackagePart();
                            PackagePart background = part.getRelatedPart(part.getRelationship(sheet.getCTWorksheet().getPicture().getId()));
                            try (InputStream image = background.getInputStream()) {
                                assertArrayEquals(WorkbookProtector.watermarkPng(visible, 82), image.readAllBytes());
                            }
                        }
                    }
                }
            }
        }
    }

    @Test void completedPasswordSurvivesCleanupAndCopiesCorrectly() throws Exception {
        var clipboard = new java.awt.datatransfer.Clipboard("test-only");
        for (char[] secret : new char[][]{PasswordGenerator.generate(), "Manual-copy-9!AbC".toCharArray()}) {
            String expected = new String(secret);
            Path source = fixture("copy-source.xlsx");
            Path output = dir.resolve("copy-" + System.nanoTime() + ".xlsx");
            String completed = ExcelWatermarkApp.protectAndGetPassword(source, output, TEXT, secret, 82, IDENTITY);
            assertArrayEquals(new char[secret.length], secret);
            assertEquals(expected, completed);
            ExcelWatermarkApp.copyCompletedPassword(clipboard, completed);
            assertEquals(expected, clipboard.getData(java.awt.datatransfer.DataFlavor.stringFlavor));
            try (POIFSFileSystem fs = new POIFSFileSystem(output.toFile(), true)) {
                assertTrue(Decryptor.getInstance(new EncryptionInfo(fs)).verifyPassword(completed));
            }
        }
        for (String invalid : new String[]{"", "   ", "\0".repeat(16)}) {
            Object previous = clipboard.getData(java.awt.datatransfer.DataFlavor.stringFlavor);
            assertThrows(IllegalStateException.class,
                    () -> ExcelWatermarkApp.copyCompletedPassword(clipboard, invalid));
            assertEquals(previous, clipboard.getData(java.awt.datatransfer.DataFlavor.stringFlavor));
        }
        var failingClipboard = new java.awt.datatransfer.Clipboard("unavailable") {
            @Override public synchronized void setContents(java.awt.datatransfer.Transferable contents,
                    java.awt.datatransfer.ClipboardOwner owner) {
                throw new IllegalStateException("clipboard unavailable");
            }
        };
        assertThrows(IllegalStateException.class,
                () -> ExcelWatermarkApp.copyCompletedPassword(failingClipboard, "Manual-copy-9!AbC"));
    }

    @Test void manualPasswordRequiresValidLengthAndMatchingConfirmation() throws Exception {
        for (String valid : new String[]{"Ab3!xy89", "A".repeat(128), " Ab3!xy89 "}) {
            char[] supplied = valid.toCharArray();
            assertDoesNotThrow(() -> ExcelWatermarkApp.validateManualPassword(supplied, valid.toCharArray()));
            assertArrayEquals(valid.toCharArray(), supplied, "不得修改或裁剪手动密码");
        }
        for (String invalid : new String[]{"", "Ab3!xy8", "A".repeat(129), "        "}) {
            assertThrows(IllegalArgumentException.class,
                    () -> ExcelWatermarkApp.validateManualPassword(invalid.toCharArray(), invalid.toCharArray()));
        }
        assertThrows(IllegalArgumentException.class,
                () -> ExcelWatermarkApp.validateManualPassword("Ab3!xy89".toCharArray(), "ab3!xy89".toCharArray()));
        char[] manual = " Ab3!xy89 ".toCharArray();
        ExcelWatermarkApp.validateManualPassword(manual, manual.clone());
        Path result = dir.resolve("manual.xlsx");
        WorkbookProtector.protect(fixture("manual-source.xlsx"), result, TEXT, manual, 82);
        try (POIFSFileSystem fs = new POIFSFileSystem(result.toFile(), true)) {
            assertTrue(Decryptor.getInstance(new EncryptionInfo(fs)).verifyPassword(new String(manual)));
            assertFalse(Decryptor.getInstance(new EncryptionInfo(fs)).verifyPassword("Ab3!xy89"));
        }
    }

    @Test void requiresExtractorAndApprovalBeforeComposingWatermark() {
        assertEquals("内部数据 · 禁止外传\nTEST-001",
                ExcelWatermarkApp.composeWatermark(" 内部数据 · 禁止外传 ", " 测试提取人 ", " TEST-001 ", false));
        assertEquals("请填写提取人。", assertThrows(IllegalArgumentException.class,
                () -> ExcelWatermarkApp.composeWatermark("水印", "　 ", "TEST-001")).getMessage());
        assertEquals("请填写审批编号。", assertThrows(IllegalArgumentException.class,
                () -> ExcelWatermarkApp.composeWatermark("水印", "测试提取人", " ")).getMessage());
        assertThrows(IllegalArgumentException.class,
                () -> ExcelWatermarkApp.composeWatermark("水印", "甲\n乙", "TEST-001"));
        assertThrows(IllegalArgumentException.class,
                () -> ExcelWatermarkApp.composeWatermark("水印", "测试提取人", "A\nB"));
        assertThrows(IllegalArgumentException.class,
                () -> ExcelWatermarkApp.composeWatermark("一\n二\n三\n四", "测试提取人", "TEST-001"));
        assertThrows(IllegalArgumentException.class, () -> new WorkbookProtector.ExportIdentity(" ", "A"));
        assertThrows(IllegalArgumentException.class, () -> new WorkbookProtector.ExportIdentity("张三", "A\nB"));
    }

    private Path fixture(String name) throws Exception {
        Path file = dir.resolve(name);
        try (XSSFWorkbook book = new XSSFWorkbook()) {
            XSSFSheet sheet = book.createSheet("虚拟数据");
            String[] labels = {"申请单号", "合作方", "金额", "校验公式", "状态", "说明"};
            Row head = sheet.createRow(0);
            for (int c = 0; c < labels.length; c++) {
                head.createCell(c).setCellValue(labels[c]);
                sheet.setColumnWidth(c, 18 * 256);
            }
            for (int r = 1; r <= 120; r++) {
                Row row = sheet.createRow(r);
                row.setHeightInPoints(20);
                row.createCell(0).setCellValue("DEMO-" + r);
                row.createCell(1).setCellValue("虚拟合作方");
                row.createCell(2).setCellValue(r * 10.5);
                row.createCell(3).setCellFormula("C" + (r + 1) + "*2");
                row.createCell(4).setCellValue("仅用于测试");
            }
            sheet.setAutoFilter(new CellRangeAddress(0, 120, 0, 5));
            sheet.createFreezePane(0, 1);
            sheet.getOddHeader().setLeft("原页眉");
            sheet.getOddFooter().setRight("第 &P 页 / 共 &N 页");
            sheet.getFirstHeader().setRight("原首页");
            sheet.getEvenFooter().setLeft("原偶数页");
            sheet.getCTWorksheet().getHeaderFooter().setDifferentFirst(true);
            sheet.getCTWorksheet().getHeaderFooter().setDifferentOddEven(true);
            sheet.getPrintSetup().setPaperSize(PrintSetup.A4_PAPERSIZE);
            sheet.getPrintSetup().setLandscape(true);
            sheet.setRowBreak(40);
            sheet.setRowBreak(80);
            book.setPrintArea(0, 0, 5, 0, 120);
            XSSFSheet second = book.createSheet("第二张表");
            second.createRow(0).createCell(0).setCellValue("第二张表原值");
            second.setColumnWidth(0, 24 * 256);
            book.getCreationHelper().createFormulaEvaluator().evaluateAll();
            try (OutputStream out = Files.newOutputStream(file)) { book.write(out); }
        }
        return file;
    }

    @Test void encryptionPreservesDataAndPrintWatermarksAcrossPages() throws Exception {
        Path source = fixture("source.xlsx");
        byte[] original = Files.readAllBytes(source);
        Path result = dir.resolve("result.xlsx");
        WorkbookProtector.protect(source, result, TEXT, PASSWORD.clone(), 82, IDENTITY);
        assertArrayEquals(original, Files.readAllBytes(source), "原文件不能被修改");
        try (POIFSFileSystem fs = new POIFSFileSystem(result.toFile(), true)) {
            EncryptionInfo info = new EncryptionInfo(fs);
            assertEquals(EncryptionMode.agile, info.getEncryptionMode());
            assertEquals(256, info.getHeader().getKeySize());
            assertFalse(Decryptor.getInstance(info).verifyPassword("wrong-password"));
            Decryptor decryptor = Decryptor.getInstance(new EncryptionInfo(fs));
            assertTrue(decryptor.verifyPassword(new String(PASSWORD)));
            try (InputStream decrypted = decryptor.getDataStream(fs); XSSFWorkbook book = new XSSFWorkbook(decrypted)) {
                assertEquals(2, book.getNumberOfSheets());
                assertEquals(IDENTITY.extractor(), book.getProperties().getCustomProperties().getProperty("提取人").getLpwstr());
                assertEquals(IDENTITY.approvalNumber(), book.getProperties().getCustomProperties().getProperty("审批编号").getLpwstr());
                XSSFSheet sheet = book.getSheetAt(0);
                assertEquals(121, sheet.getPhysicalNumberOfRows());
                for (int r = 1; r <= 120; r++) {
                    assertEquals("DEMO-" + r, sheet.getRow(r).getCell(0).getStringCellValue());
                    assertEquals(r * 10.5, sheet.getRow(r).getCell(2).getNumericCellValue());
                    assertEquals("C" + (r + 1) + "*2", sheet.getRow(r).getCell(3).getCellFormula());
                    assertEquals(r * 21.0, sheet.getRow(r).getCell(3).getNumericCellValue());
                }
                assertTrue(sheet.getCTWorksheet().isSetAutoFilter());
                assertTrue(sheet.getPaneInformation().isFreezePane());
                assertArrayEquals(new int[]{40, 80}, sheet.getRowBreaks());
                assertTrue(book.getPrintArea(0).contains("$A$1:$F$121"));
                assertEquals("原页眉", sheet.getOddHeader().getLeft());
                assertEquals("原首页", sheet.getFirstHeader().getRight());
                assertEquals("原偶数页", sheet.getEvenFooter().getLeft());
                assertEquals("第 &P 页 / 共 &N 页", sheet.getOddFooter().getRight());
                assertTrue(sheet.getCTWorksheet().getHeaderFooter().getDifferentFirst());
                assertTrue(sheet.getCTWorksheet().getHeaderFooter().getDifferentOddEven());
                assertFalse(sheet.getCTWorksheet().getHeaderFooter().getScaleWithDoc());
                assertTrue(sheet.getOddHeader().getCenter().contains("&G"));
                assertTrue(sheet.getFirstHeader().getCenter().contains("&G"));
                assertTrue(sheet.getEvenHeader().getCenter().contains("&G"));
                for (String footer : new String[]{sheet.getOddFooter().getCenter(),
                        sheet.getFirstFooter().getCenter(), sheet.getEvenFooter().getCenter()}) {
                    assertTrue(footer.contains("TEST-001"));
                    assertFalse(footer.contains("测试提取人"));
                    assertFalse(footer.contains("审批编号："));
                    assertFalse(footer.contains("提取人："));
                }
                assertFalse(book.getSheetAt(1).getCTWorksheet().getHeaderFooter().getDifferentFirst());
                assertFalse(book.getSheetAt(1).getCTWorksheet().getHeaderFooter().getDifferentOddEven());
                for (int i = 0; i < book.getNumberOfSheets(); i++) {
                    validateImageRelations(book.getSheetAt(i));
                    validateTransparentIdentity(book.getSheetAt(i), IDENTITY, 2);
                }
                assertEquals("第二张表原值", book.getSheetAt(1).getRow(0).getCell(0).getStringCellValue());
            }
        }
        assertEquals(0, stagingCount());
        Files.copy(source, Path.of("target", "print-source.xlsx"), StandardCopyOption.REPLACE_EXISTING);
        Files.copy(result, Path.of("target", "print-encrypted.xlsx"), StandardCopyOption.REPLACE_EXISTING);
    }

    @Test void preservesExistingCustomPropertiesAndDrawingsWithTransparentIdentity() throws Exception {
        Path source = dir.resolve("existing-metadata.xlsx");
        byte[] originalPicture;
        try (XSSFWorkbook book = new XSSFWorkbook()) {
            book.getProperties().getCustomProperties().addProperty("业务标识", "保留原值");
            book.getProperties().getCustomProperties().addProperty("计数", 42);
            book.getProperties().getCustomProperties().addProperty("提取人", "旧提取人");
            book.getProperties().getCustomProperties().addProperty("审批编号", "OLD");
            XSSFSheet sheet = book.createSheet("已有绘图");
            sheet.setColumnWidth(0, 20 * 256);
            sheet.createRow(0).createCell(0).setCellValue("原始单元格");
            var drawing = sheet.createDrawingPatriarch();
            var anchor = new XSSFClientAnchor(0, 0, 0, 0, 0, 5, 4, 9);
            drawing.createTextbox(anchor).setText("原有文本框");
            drawing.createChart(new XSSFClientAnchor(0, 0, 0, 0, 5, 5, 10, 15)).setTitleText("原有图表");
            ByteArrayOutputStream png = new ByteArrayOutputStream();
            ImageIO.write(new BufferedImage(2, 2, BufferedImage.TYPE_INT_RGB), "png", png);
            originalPicture = png.toByteArray();
            drawing.createPicture(new XSSFClientAnchor(0, 0, 0, 0, 0, 10, 2, 12),
                    book.addPicture(originalPicture, Workbook.PICTURE_TYPE_PNG));
            try (OutputStream out = Files.newOutputStream(source)) { book.write(out); }
        }
        byte[] original = Files.readAllBytes(source);
        var identity = new WorkbookProtector.ExportIdentity("张<&三", "A&<001>");
        String visible = ExcelWatermarkApp.composeWatermark("内部数据", identity.extractor(), identity.approvalNumber(), false);
        Path result = dir.resolve("metadata-encrypted.xlsx");
        WorkbookProtector.protect(source, result, visible, PASSWORD.clone(), 82, identity);
        assertArrayEquals(original, Files.readAllBytes(source));
        try (POIFSFileSystem fs = new POIFSFileSystem(result.toFile(), true)) {
            Decryptor decryptor = Decryptor.getInstance(new EncryptionInfo(fs));
            assertTrue(decryptor.verifyPassword(new String(PASSWORD)));
            try (InputStream in = decryptor.getDataStream(fs); XSSFWorkbook book = new XSSFWorkbook(in)) {
                var properties = book.getProperties().getCustomProperties();
                assertEquals("保留原值", properties.getProperty("业务标识").getLpwstr());
                assertEquals(42, properties.getProperty("计数").getI4());
                assertEquals(identity.extractor(), properties.getProperty("提取人").getLpwstr());
                assertEquals(identity.approvalNumber(), properties.getProperty("审批编号").getLpwstr());
                assertEquals(4, properties.getUnderlyingProperties().sizeOfPropertyArray());
                assertTrue(properties.getUnderlyingProperties().validate());
                var sheet = book.getSheetAt(0);
                assertEquals("原始单元格", sheet.getRow(0).getCell(0).getStringCellValue());
                validateImageRelations(sheet);
                validateTransparentIdentity(sheet, identity, 5);
                assertTrue(sheet.getDrawingPatriarch().getShapes().stream().anyMatch(
                        shape -> shape instanceof XSSFSimpleShape simple && simple.getText().equals("原有文本框")));
                assertEquals(1, sheet.getDrawingPatriarch().getCharts().size());
                assertEquals("原有图表", sheet.getDrawingPatriarch().getCharts().get(0).getTitleText().getString());
                assertTrue(book.getAllPictures().stream().anyMatch(picture -> Arrays.equals(originalPicture, picture.getData())));
                assertFalse(sheet.getOddFooter().getCenter().contains(identity.extractor()));
            }
        }
    }

    private void validateTransparentIdentity(XSSFSheet sheet, WorkbookProtector.ExportIdentity identity, int totalShapes) {
        var drawing = sheet.getDrawingPatriarch();
        if (totalShapes == 0) {
            assertNull(drawing);
            assertFalse(sheet.getCTWorksheet().isSetDrawing());
            return;
        }
        assertNotNull(drawing);
        assertEquals(totalShapes, drawing.getShapes().size());
        var errors = new java.util.ArrayList<org.apache.xmlbeans.XmlError>();
        assertTrue(drawing.getCTDrawing().validate(new org.apache.xmlbeans.XmlOptions().setErrorListener(errors)), () -> errors.toString());
        int count = 0;
        var ids = new java.util.HashSet<Long>();
        for (var shape : drawing.getShapes()) {
            if (!(shape instanceof XSSFSimpleShape simple)) continue;
            assertTrue(ids.add((long) simple.getShapeId()));
            if (!simple.getShapeName().startsWith("Trace.")) continue;
            count++;
            assertTrue(simple.getShapeName().startsWith("Trace.Extractor.") ? identity.hiddenExtractor() : identity.hiddenApproval());
            assertEquals(simple.getShapeName().startsWith("Trace.Extractor.") ? identity.extractor() : identity.approvalNumber(), simple.getText());
            var ct = simple.getCTShape();
            assertTrue(ct.getSpPr().isSetNoFill());
            assertTrue(ct.getSpPr().getLn().isSetNoFill());
            for (var paragraph : ct.getTxBody().getPArray()) {
                for (var run : paragraph.getRArray()) {
                    assertTrue(run.getRPr().isSetSolidFill());
                    assertEquals(1, run.getRPr().getSolidFill().getSrgbClr().sizeOfAlphaArray());
                    assertEquals("0", run.getRPr().getSolidFill().getSrgbClr().getAlphaArray(0).getVal().toString());
                }
            }
        }
        assertEquals((identity.hiddenExtractor() ? 1 : 0) + (identity.hiddenApproval() ? 1 : 0), count);
    }

    private void validateImageRelations(XSSFSheet sheet) throws Exception {
        var schemaErrors = new java.util.ArrayList<org.apache.xmlbeans.XmlError>();
        assertTrue(sheet.getCTWorksheet().validate(new org.apache.xmlbeans.XmlOptions().setErrorListener(schemaErrors)),
                () -> "工作表 OOXML 应符合 schema: " + schemaErrors);
        PackagePart part = sheet.getPackagePart();
        PackagePart background = part.getRelatedPart(part.getRelationship(sheet.getCTWorksheet().getPicture().getId()));
        try (InputStream in = background.getInputStream()) { assertNotNull(ImageIO.read(in)); }
        PackagePart vml = part.getRelatedPart(part.getRelationship(sheet.getCTWorksheet().getLegacyDrawingHF().getId()));
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        try (InputStream in = vml.getInputStream()) {
            var xml = factory.newDocumentBuilder().parse(in);
            var shape = (org.w3c.dom.Element) xml.getElementsByTagNameNS("urn:schemas-microsoft-com:vml", "shape").item(0);
            assertEquals("CH", shape.getAttribute("id"));
            var shapes = xml.getElementsByTagNameNS("urn:schemas-microsoft-com:vml", "shape");
            assertEquals(3, shapes.getLength());
            assertEquals("CHEVEN", ((org.w3c.dom.Element) shapes.item(1)).getAttribute("id"));
            assertEquals("CHFIRST", ((org.w3c.dom.Element) shapes.item(2)).getAttribute("id"));
            var image = (org.w3c.dom.Element) xml.getElementsByTagNameNS("urn:schemas-microsoft-com:vml", "imagedata").item(0);
            String id = image.getAttributeNS("urn:schemas-microsoft-com:office:office", "relid");
            assertEquals(background.getPartName(), vml.getRelatedPart(vml.getRelationship(id)).getPartName());
        }
    }

    @Test void refusesOverwriteAndInvalidInputs() throws Exception {
        Path input = fixture("input.xlsx");
        byte[] original = Files.readAllBytes(input);
        assertThrows(IOException.class, () -> WorkbookProtector.protect(input, input, TEXT, PASSWORD, 82));
        Path output = dir.resolve("existing.xlsx");
        Files.writeString(output, "已有文件");
        assertThrows(IOException.class, () -> WorkbookProtector.protect(input, output, TEXT, PASSWORD, 82));
        assertEquals("已有文件", Files.readString(output));
        assertThrows(IllegalArgumentException.class, () -> WorkbookProtector.protect(input, dir.resolve("new.xlsx"), " ", PASSWORD, 82));
        assertThrows(IllegalArgumentException.class, () -> WorkbookProtector.protect(input, dir.resolve("new.xlsx"), TEXT, "123".toCharArray(), 82));
        assertThrows(IllegalArgumentException.class, () -> WorkbookProtector.protect(input, dir.resolve("new.xlsx"), TEXT, PASSWORD, 100));
        assertFalse(Files.exists(dir.resolve("new.xlsx")));
        assertArrayEquals(original, Files.readAllBytes(input));
    }

    @Test void refusesEncryptedInputAndDoesNotLeaveOutput() throws Exception {
        Path source = fixture("plain.xlsx"), encrypted = dir.resolve("encrypted.xlsx"), again = dir.resolve("again.xlsx");
        WorkbookProtector.protect(source, encrypted, TEXT, PASSWORD, 82);
        assertThrows(IOException.class, () -> WorkbookProtector.protect(encrypted, again, TEXT, PASSWORD, 82));
        assertFalse(Files.exists(again));
        assertEquals(0, stagingCount());
    }

    @Test void rejectsExistingBackgroundAndFooterOverflow() throws Exception {
        Path source = fixture("existing-picture.xlsx");
        try (XSSFWorkbook book = new XSSFWorkbook(Files.newInputStream(source))) {
            book.getSheetAt(0).getCTWorksheet().addNewPicture().setId("existing-background");
            try (OutputStream out = Files.newOutputStream(source)) { book.write(out); }
        }
        Path output = dir.resolve("output.xlsx");
        assertThrows(IOException.class, () -> WorkbookProtector.protect(source, output, TEXT, PASSWORD, 82));
        assertFalse(Files.exists(output));

        Path longFooter = fixture("long-footer.xlsx");
        try (InputStream in = Files.newInputStream(longFooter); XSSFWorkbook book = new XSSFWorkbook(in)) {
            book.getSheetAt(0).getOddFooter().setCenter("旧".repeat(240));
            try (OutputStream out = Files.newOutputStream(longFooter)) { book.write(out); }
        }
        assertThrows(IOException.class, () -> WorkbookProtector.protect(longFooter, output, TEXT, PASSWORD, 82));
        assertFalse(Files.exists(output));
        assertEquals(0, stagingCount());
    }

    @Test void watermarkPngHasTransparentBackgroundAndVisibleInk() throws Exception {
        byte[] png = WorkbookProtector.watermarkPng(TEXT, 82);
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(png));
        assertEquals(0, image.getRGB(0, 0) >>> 24);
        int ink = 0, maxAlpha = 0;
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int alpha = image.getRGB(x, y) >>> 24;
                if (alpha > 0) ink++;
                maxAlpha = Math.max(maxAlpha, alpha);
            }
        }
        assertTrue(ink > 1000);
        assertTrue(maxAlpha >= 45 && maxAlpha <= 47);
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 2; col++) {
                int tileInk = 0;
                for (int y = row * 240; y < (row + 1) * 240; y++) {
                    for (int x = col * 600; x < (col + 1) * 600; x++) {
                        if ((image.getRGB(x, y) >>> 24) > 0) tileInk++;
                    }
                }
                assertTrue(tileInk > 500, "六个水印区域均需包含可见文字");
            }
        }
        // 仅保存虚拟水印图片用于视觉核对，不含业务数据。
        Path review = Path.of("target", "watermark-preview.png");
        Files.createDirectories(review.getParent());
        Files.write(review, png);
        BufferedImage whitePreview = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
        var graphics = whitePreview.createGraphics();
        try {
            graphics.setColor(java.awt.Color.WHITE);
            graphics.fillRect(0, 0, whitePreview.getWidth(), whitePreview.getHeight());
            graphics.drawImage(image, 0, 0, null);
        } finally { graphics.dispose(); }
        ImageIO.write(whitePreview, "png", Path.of("target", "watermark-density-preview.png").toFile());
    }

    private long stagingCount() throws IOException {
        try (var stream = Files.list(dir)) { return stream.filter(p -> p.getFileName().toString().startsWith(".excel-watermark-")).count(); }
    }

    @Test void randomPasswordsAlwaysContainAllFourCharacterGroups() {
        for (int i = 0; i < 200; i++) {
            char[] secret = PasswordGenerator.generate();
            String value = new String(secret);
            assertEquals(16, value.length());
            assertTrue(value.matches(".*[A-Z].*"));
            assertTrue(value.matches(".*[a-z].*"));
            assertTrue(value.matches(".*[0-9].*"));
            assertTrue(value.matches(".*[^A-Za-z0-9].*"));
            Arrays.fill(secret, '\0');
        }
    }
}
