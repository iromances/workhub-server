package demo;

import org.w3c.dom.*;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import java.io.*;
import java.net.URI;
import java.util.*;
import java.util.zip.ZipFile;

import static demo.StreamingXlsxWatermark.*;

/** 只处理小型属性和绘图部件，不加载单元格或共享字符串。 */
final class TraceMetadata {
    private static final String R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static final String PR = "http://schemas.openxmlformats.org/package/2006/relationships";
    private static final String S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static final String CP = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties";
    private static final String VT = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes";
    private static final String XDR = "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing";
    private static final String A = "http://schemas.openxmlformats.org/drawingml/2006/main";
    final Map<String, Document> parts = new LinkedHashMap<>();
    final Map<String, Document> sheetRelationships = new HashMap<>();
    final Map<String, String> newDrawingIds = new HashMap<>();

    void addProperties(ZipFile source, Document types, WorkbookProtector.ExportIdentity identity, String token) throws Exception {
        if (!identity.extractorProperty() && !identity.approvalProperty()) return;
        Document rels = source.getEntry("_rels/.rels") == null
                ? newDocument(PR, "Relationships") : readSmallXml(source, "_rels/.rels");
        Element relation = null;
        NodeList list = rels.getElementsByTagNameNS(PR, "Relationship");
        for (int i = 0; i < list.getLength(); i++) {
            Element item = (Element) list.item(i);
            if ((R + "/custom-properties").equals(item.getAttribute("Type"))) {
                if (relation != null) throw new IOException("文件包含多个自定义属性关系。");
                relation = item;
            }
        }
        String path;
        Document properties;
        if (relation == null) {
            path = source.getEntry("docProps/custom.xml") == null
                    ? "docProps/custom.xml" : "docProps/trace-" + token + ".xml";
            properties = newDocument(CP, "Properties");
            addRelation(rels, "traceProperties" + token, R + "/custom-properties", path);
        } else {
            path = internalTarget("", relation);
            properties = readSmallXml(source, path);
        }
        if (!CP.equals(properties.getDocumentElement().getNamespaceURI()))
            throw new IOException("自定义属性格式不受支持。");
        if (identity.extractorProperty()) setProperty(properties, "提取人", identity.extractor());
        if (identity.approvalProperty()) setProperty(properties, "审批编号", identity.approvalNumber());
        addContentType(types, path, "application/vnd.openxmlformats-officedocument.custom-properties+xml");
        parts.put("_rels/.rels", rels);
        parts.put(path, properties);
    }

    private static void setProperty(Document doc, String name, String value) throws IOException {
        long maxId = 1;
        NodeList list = doc.getElementsByTagNameNS(CP, "property");
        List<Node> old = new ArrayList<>();
        for (int i = 0; i < list.getLength(); i++) {
            Element item = (Element) list.item(i);
            maxId = Math.max(maxId, Long.parseLong(item.getAttribute("pid")));
            if (name.equals(item.getAttribute("name"))) old.add(item);
        }
        if (maxId >= Integer.MAX_VALUE) throw new IOException("自定义属性编号超出支持范围。");
        old.forEach(node -> node.getParentNode().removeChild(node));
        Element property = child(doc.getDocumentElement(), CP, "property");
        property.setAttribute("fmtid", "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}");
        property.setAttribute("pid", Long.toString(maxId + 1));
        property.setAttribute("name", name);
        child(property, VT, "vt:lpwstr").setTextContent(value);
    }

    void addSheet(ZipFile source, Document types, String sheetPath, String relsPath,
                  WorkbookProtector.ExportIdentity identity, String token) throws Exception {
        if (!identity.hiddenExtractor() && !identity.hiddenApproval()) return;
        Document rels = source.getEntry(relsPath) == null
                ? newDocument(PR, "Relationships") : readSmallXml(source, relsPath);
        NodeList list = rels.getElementsByTagNameNS(PR, "Relationship");
        boolean hasDrawingRelation = false;
        for (int i = 0; i < list.getLength(); i++) {
            if ((R + "/drawing").equals(((Element) list.item(i)).getAttribute("Type"))) hasDrawingRelation = true;
        }
        // 通常导出表没有绘图关系，此时无须额外扫描大型工作表。
        String id = hasDrawingRelation ? drawingId(source, sheetPath) : null;
        String drawingPath;
        Document drawing;
        if (id == null) {
            drawingPath = "xl/drawings/trace-" + token + "-" + sheetRelationships.size() + ".xml";
            drawing = newDocument(XDR, "xdr:wsDr");
            String newId = "traceDrawing" + token;
            addRelation(rels, newId, R + "/drawing", "../drawings/" + drawingPath.substring("xl/drawings/".length()));
            newDrawingIds.put(sheetPath, newId);
        } else {
            Element found = null;
            for (int i = 0; i < list.getLength(); i++) {
                Element item = (Element) list.item(i);
                if (id.equals(item.getAttribute("Id")) && (R + "/drawing").equals(item.getAttribute("Type"))) found = item;
            }
            if (found == null) throw new IOException("工作表缺少有效绘图关系。");
            drawingPath = internalTarget(sheetPath, found);
            drawing = parts.get(drawingPath);
            if (drawing == null) drawing = readSmallXml(source, drawingPath);
        }
        if (!XDR.equals(drawing.getDocumentElement().getNamespaceURI()))
            throw new IOException("绘图格式不受支持，无法安全追加透明水印。");
        // 同一绘图若被多个工作表共享，只追加一次。
        if (!parts.containsKey(drawingPath)) {
            long nextId = 1;
            NodeList ids = drawing.getElementsByTagNameNS(XDR, "cNvPr");
            for (int i = 0; i < ids.getLength(); i++)
                nextId = Math.max(nextId, Long.parseLong(((Element) ids.item(i)).getAttribute("id")) + 1);
            if (nextId > 4294967294L) throw new IOException("绘图编号超出支持范围。");
            if (identity.hiddenExtractor())
                appendTransparentText(drawing, nextId++, "Trace.Extractor." + token, identity.extractor(), 2);
            if (identity.hiddenApproval())
                appendTransparentText(drawing, nextId, "Trace.Approval." + token, identity.approvalNumber(), 4);
        }
        addContentType(types, drawingPath, "application/vnd.openxmlformats-officedocument.drawing+xml");
        parts.put(drawingPath, drawing);
        sheetRelationships.put(relsPath, rels);
    }

    private static String drawingId(ZipFile source, String path) throws Exception {
        try (InputStream in = source.getInputStream(source.getEntry(path))) {
            XMLStreamReader reader = inputFactory().createXMLStreamReader(in);
            try {
                int depth = 0;
                while (reader.hasNext()) {
                    int event = reader.next();
                    if (event == XMLStreamConstants.START_ELEMENT) {
                        depth++;
                        if (depth == 2 && S.equals(reader.getNamespaceURI()) && "drawing".equals(reader.getLocalName())) {
                            String id = reader.getAttributeValue(R, "id");
                            if (id == null || id.isBlank()) throw new IOException("工作表绘图缺少关系编号。");
                            return id;
                        }
                    } else if (event == XMLStreamConstants.END_ELEMENT) depth--;
                }
                return null;
            } finally { reader.close(); }
        }
    }

    private static String internalTarget(String owner, Element relation) throws IOException {
        if ("External".equalsIgnoreCase(relation.getAttribute("TargetMode")))
            throw new IOException("不支持外部属性或绘图关系。");
        URI target = URI.create(relation.getAttribute("Target"));
        if (target.isAbsolute() || target.getRawAuthority() != null || target.getRawQuery() != null || target.getRawFragment() != null)
            throw new IOException("文件关系目标格式不受支持。");
        String resolved = URI.create("/" + owner).resolve(target).normalize().getPath();
        if (resolved == null || !resolved.startsWith("/") || resolved.contains("..") || resolved.endsWith("/"))
            throw new IOException("文件关系目标无效。");
        return resolved.substring(1);
    }

    private static void appendTransparentText(Document doc, long id, String name, String text, int row) {
        Element anchor = child(doc.getDocumentElement(), XDR, "xdr:oneCellAnchor");
        Element from = child(anchor, XDR, "xdr:from");
        child(from, XDR, "xdr:col").setTextContent("1");
        child(from, XDR, "xdr:colOff").setTextContent("0");
        child(from, XDR, "xdr:row").setTextContent(Integer.toString(row));
        child(from, XDR, "xdr:rowOff").setTextContent("0");
        extent(child(anchor, XDR, "xdr:ext"));
        Element shape = child(anchor, XDR, "xdr:sp");
        Element nv = child(shape, XDR, "xdr:nvSpPr");
        Element props = child(nv, XDR, "xdr:cNvPr");
        props.setAttribute("id", Long.toString(id));
        props.setAttribute("name", name);
        child(nv, XDR, "xdr:cNvSpPr").setAttribute("txBox", "1");
        Element geometry = child(shape, XDR, "xdr:spPr");
        Element transform = child(geometry, A, "a:xfrm");
        Element offset = child(transform, A, "a:off");
        offset.setAttribute("x", "0"); offset.setAttribute("y", "0");
        extent(child(transform, A, "a:ext"));
        Element preset = child(geometry, A, "a:prstGeom");
        preset.setAttribute("prst", "rect"); child(preset, A, "a:avLst");
        child(geometry, A, "a:noFill");
        child(child(geometry, A, "a:ln"), A, "a:noFill");
        Element body = child(shape, XDR, "xdr:txBody");
        child(body, A, "a:bodyPr").setAttribute("wrap", "none");
        child(body, A, "a:lstStyle");
        Element paragraph = child(body, A, "a:p");
        transparentFont(child(child(paragraph, A, "a:pPr"), A, "a:defRPr"));
        Element run = child(paragraph, A, "a:r");
        transparentFont(child(run, A, "a:rPr"));
        child(run, A, "a:t").setTextContent(text);
        transparentFont(child(paragraph, A, "a:endParaRPr"));
        Element client = child(anchor, XDR, "xdr:clientData");
        client.setAttribute("fLocksWithSheet", "0");
        client.setAttribute("fPrintsWithSheet", "1");
    }

    private static void transparentFont(Element properties) {
        properties.setAttribute("sz", "1200");
        Element color = child(child(properties, A, "a:solidFill"), A, "a:srgbClr");
        color.setAttribute("val", "000000");
        child(color, A, "a:alpha").setAttribute("val", "0");
    }

    private static void extent(Element ext) { ext.setAttribute("cx", "3810000"); ext.setAttribute("cy", "381000"); }
    private static Element child(Element parent, String ns, String name) {
        Element item = parent.getOwnerDocument().createElementNS(ns, name);
        parent.appendChild(item);
        return item;
    }
}
