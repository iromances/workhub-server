package demo;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;

/** 水印图片生成与公开处理入口；Excel 内容采用流式读写，不覆盖输入。 */
public final class WorkbookProtector {
    private WorkbookProtector() {}

    public static void protect(Path input, Path output, String watermark, char[] password, int transparency) throws Exception {
        protect(input, output, watermark, password, transparency, null);
    }

    public static void protect(Path input, Path output, String watermark, char[] password, int transparency,
                               ExportIdentity identity) throws Exception {
        StreamingXlsxWatermark.protect(input, output, watermark, password, transparency, identity);
    }

    public record ExportIdentity(String extractor, String approvalNumber, boolean hiddenExtractor,
                                 boolean hiddenApproval, boolean extractorProperty, boolean approvalProperty) {
        public ExportIdentity(String extractor, String approvalNumber) {
            this(extractor, approvalNumber, true);
        }
        public ExportIdentity(String extractor, String approvalNumber, boolean hiddenExtractor) {
            this(extractor, approvalNumber, hiddenExtractor, true, true, true);
        }
        public ExportIdentity {
            extractor = identityField(extractor, "提取人");
            approvalNumber = identityField(approvalNumber, "审批编号");
        }
        private static String identityField(String value, String label) {
            if (value == null || value.isBlank()) throw new IllegalArgumentException("请填写" + label + "。");
            String text = value.strip();
            if (text.length() > 120 || text.codePoints().anyMatch(Character::isISOControl))
                throw new IllegalArgumentException(label + "最多 120 个字符，不能包含换行或控制字符。");
            return text;
        }
    }

    static void validateText(String text, char[] password, int transparency) {
        if (text == null || text.isBlank()) throw new IllegalArgumentException("请输入水印文字。");
        if (text.length() > 120 || text.lines().count() > 4) {
            throw new IllegalArgumentException("水印最多 120 个字符、4 行，请适当缩短。");
        }
        if (text.chars().anyMatch(c -> Character.isISOControl(c) && c != '\n' && c != '\r')) {
            throw new IllegalArgumentException("水印不能包含换行以外的控制字符。");
        }
        validatePassword(password);
        if (transparency < 50 || transparency > 90) {
            throw new IllegalArgumentException("透明度需在 50%～90% 之间。");
        }
    }

    static void validatePassword(char[] password) {
        if (password == null || password.length < 8 || password.length > 128
                || new String(password).isBlank()) {
            throw new IllegalArgumentException("打开密码需要 8～128 个字符，不能全为空格。");
        }
    }

    static byte[] watermarkPng(String text, int transparency) throws IOException {
        int width = 1200, height = 720;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            String[] lines = text.split("\\R", -1);
            Font font = chooseFont(text);
            // 每张平铺图片包含 2 列 × 3 行完整水印，打印页眉也使用同一图片。
            int columns = 2, rows = 3;
            int tileWidth = width / columns, tileHeight = height / rows;
            double angle = Math.toRadians(-27);
            boolean fits = false;
            for (int size = 34; size >= 10; size--) {
                g.setFont(font.deriveFont((float) size));
                FontMetrics metrics = g.getFontMetrics();
                int maxWidth = 0;
                for (String line : lines) maxWidth = Math.max(maxWidth, metrics.stringWidth(line));
                int textHeight = metrics.getHeight() * lines.length;
                double rotatedWidth = maxWidth * Math.cos(angle) + textHeight * Math.abs(Math.sin(angle));
                double rotatedHeight = maxWidth * Math.abs(Math.sin(angle)) + textHeight * Math.cos(angle);
                if (rotatedWidth <= tileWidth - 40 && rotatedHeight <= tileHeight - 30) {
                    fits = true;
                    break;
                }
            }
            if (!fits) throw new IOException("水印文字过长，密集排列会被裁切，请缩短文字或分行。");
            g.setColor(new Color(0, 0, 0, Math.round(255 * (100 - transparency) / 100f)));
            FontMetrics metrics = g.getFontMetrics();
            for (int row = 0; row < rows; row++) {
                for (int column = 0; column < columns; column++) {
                    Graphics2D tile = (Graphics2D) g.create();
                    try {
                        tile.translate((column + 0.5) * tileWidth, (row + 0.5) * tileHeight);
                        tile.rotate(angle);
                        int y = -(lines.length * metrics.getHeight()) / 2 + metrics.getAscent();
                        for (String line : lines) {
                            tile.drawString(line, -metrics.stringWidth(line) / 2, y);
                            y += metrics.getHeight();
                        }
                    } finally { tile.dispose(); }
                }
            }
        } finally {
            g.dispose();
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(image, "png", out);
        return out.toByteArray();
    }

    private static Font chooseFont(String text) throws IOException {
        String[] preferred = {"PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", "SimHei", "Dialog"};
        for (String family : preferred) {
            Font font = new Font(family, Font.PLAIN, 70);
            if (font.canDisplayUpTo(text.replace("\n", "").replace("\r", "")) == -1) return font;
        }
        throw new IOException("本机字体无法显示部分水印字符，请换用本机支持的文字或字体。");
    }

    static String vmlXml(String imageRelationId) {
        return """
                <xml xmlns:v="urn:schemas-microsoft-com:vml"
                     xmlns:o="urn:schemas-microsoft-com:office:office"
                     xmlns:x="urn:schemas-microsoft-com:office:excel">
                  <o:shapelayout v:ext="edit"><o:idmap v:ext="edit" data="1"/></o:shapelayout>
                  <v:shapetype id="_x0000_t75" coordsize="21600,21600" o:spt="75"
                      o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
                    <v:stroke joinstyle="miter"/>
                    <v:formulas>
                      <v:f eqn="if lineDrawn pixelLineWidth 0"/><v:f eqn="sum @0 1 0"/>
                      <v:f eqn="sum 0 0 @1"/><v:f eqn="prod @2 1 2"/>
                      <v:f eqn="prod @3 21600 pixelWidth"/><v:f eqn="prod @3 21600 pixelHeight"/>
                      <v:f eqn="sum @0 0 1"/><v:f eqn="prod @6 1 2"/>
                      <v:f eqn="prod @7 21600 pixelWidth"/><v:f eqn="sum @8 21600 0"/>
                      <v:f eqn="prod @7 21600 pixelHeight"/><v:f eqn="sum @10 21600 0"/>
                    </v:formulas>
                    <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
                    <o:lock v:ext="edit" aspectratio="t"/>
                  </v:shapetype>
                  <v:shape id="CH" o:spid="_x0000_s1025" type="#_x0000_t75"
                      style="position:absolute;margin-left:0;margin-top:72pt;width:360pt;height:216pt;z-index:1">
                    <v:imagedata o:relid="%1$s" o:title="watermark"/>
                    <o:lock v:ext="edit" rotation="t"/>
                  </v:shape>
                  <v:shape id="CHEVEN" o:spid="_x0000_s1026" type="#_x0000_t75"
                      style="position:absolute;margin-left:0;margin-top:72pt;width:360pt;height:216pt;z-index:1">
                    <v:imagedata o:relid="%1$s" o:title="watermark"/>
                    <o:lock v:ext="edit" rotation="t"/>
                  </v:shape>
                  <v:shape id="CHFIRST" o:spid="_x0000_s1027" type="#_x0000_t75"
                      style="position:absolute;margin-left:0;margin-top:72pt;width:360pt;height:216pt;z-index:1">
                    <v:imagedata o:relid="%1$s" o:title="watermark"/>
                    <o:lock v:ext="edit" rotation="t"/>
                  </v:shape>
                </xml>
                """.formatted(imageRelationId);
    }
}
