package demo;

import java.security.SecureRandom;

/** 每个密码恰好 16 位，并且四类字符都至少出现一次。 */
public final class PasswordGenerator {
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String[] GROUPS = {
            "ABCDEFGHJKLMNPQRSTUVWXYZ", "abcdefghijkmnopqrstuvwxyz", "23456789", "!@#$%&*+-_=?"
    };
    private PasswordGenerator() {}

    public static char[] generate() {
        char[] result = new char[16];
        String all = String.join("", GROUPS);
        for (int i = 0; i < GROUPS.length; i++) result[i] = pick(GROUPS[i]);
        for (int i = GROUPS.length; i < result.length; i++) result[i] = pick(all);
        for (int i = result.length - 1; i > 0; i--) {
            int j = RANDOM.nextInt(i + 1);
            char t = result[i]; result[i] = result[j]; result[j] = t;
        }
        return result;
    }

    private static char pick(String characters) { return characters.charAt(RANDOM.nextInt(characters.length())); }
}
