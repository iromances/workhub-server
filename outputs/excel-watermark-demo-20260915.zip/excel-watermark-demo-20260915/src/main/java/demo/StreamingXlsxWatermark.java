package demo;

import org.apache.poi.poifs.crypt.*;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xssf.usermodel.helpers.HeaderFooterHelper;
import org.w3c.dom.*;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.*;
import javax.xml.stream.events.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** 流式修改 worksheet 元数据，sharedStrings 和数据单元格不加载为内存对象。 */
final class StreamingXlsxWatermark {
    private static final String S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static final String R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    private static final String PR = "http://schemas.openxmlformats.org/package/2006/relationships";
    private static final String CT = "http://schemas.openxmlformats.org/package/2006/content-types";
    private static final long MAX_ENTRY = 1024L * 1024 * 1024;
    private static final List<String> ORDER = List.of(("sheetPr dimension sheetViews sheetFormatPr cols sheetData "
            + "sheetCalcPr sheetProtection protectedRanges scenarios autoFilter sortState dataConsolidate customSheetViews "
            + "mergeCells phoneticPr conditionalFormatting dataValidations hyperlinks printOptions pageMargins pageSetup "
            + "headerFooter rowBreaks colBreaks customProperties cellWatches ignoredErrors smartTags drawing legacyDrawing "
            + "legacyDrawingHF picture oleObjects controls webPublishItems tableParts extLst").split(" "));

    private record SheetInfo(String name, String rels, String vml, String vmlRels, String backgroundId, String headerId) {}

    static void protect(Path input, Path output, String text, char[] password, int transparency,
                        WorkbookProtector.ExportIdentity identity) throws Exception {
        WorkbookProtector.validateText(text, password, transparency);
        input = input.toAbsolutePath().normalize();
        output = output.toAbsolutePath().normalize();
        if (!input.toString().toLowerCase(Locale.ROOT).endsWith(".xlsx")
                || !output.toString().toLowerCase(Locale.ROOT).endsWith(".xlsx")) {
            throw new IOException("输入和输出都必须是 .xlsx 文件。");
        }
        if (!Files.isRegularFile(input)) throw new IOException("输入文件不存在。");
        if (input.equals(output) || Files.exists(output)) throw new IOException("目标文件已存在，请选择新的文件名。");
        if (!Files.isDirectory(output.getParent())) throw new IOException("输出目录不存在。");
        if (Files.size(input) > 500L * 1024 * 1024) throw new IOException("此 Demo 限制输入文件最大 500 MiB。");
        Path staging = null;
        try (ZipFile source = new ZipFile(input.toFile()); POIFSFileSystem encrypted = new POIFSFileSystem()) {
            String token = UUID.randomUUID().toString();
            String imageName = "xl/media/watermark-" + token + ".png";
            Map<String, SheetInfo> sheets = new LinkedHashMap<>();
            Set<String> names = new HashSet<>();
            long total = 0;
            for (ZipEntry entry : Collections.list(source.entries())) {
                if (!names.add(entry.getName())) throw new IOException("文件包含重复的 ZIP 条目。");
                if (entry.getName().startsWith("_xmlsignatures/")) throw new IOException("不支持数字签名文件。");
                total += entry.getSize();
                if (entry.getSize() < 0 || entry.getSize() > MAX_ENTRY || total > 2 * MAX_ENTRY) {
                    throw new IOException("解压后文件过大，此 Demo 限制单条目 1 GiB、总计 2 GiB。");
                }
                if (entry.getName().matches("xl/worksheets/[^/]+\\.xml")) {
                    String leaf = entry.getName().substring("xl/worksheets/".length());
                    String vml = "xl/drawings/watermark-" + token + "-" + sheets.size() + ".vml";
                    sheets.put(entry.getName(), new SheetInfo(entry.getName(), "xl/worksheets/_rels/" + leaf + ".rels",
                            vml, "xl/drawings/_rels/" + vml.substring("xl/drawings/".length()) + ".rels",
                            "wmBackground" + token, "wmHeader" + token));
                }
            }
            if (sheets.isEmpty()) throw new IOException("未找到普通 Excel 工作表。");
            Document types = readSmallXml(source, "[Content_Types].xml");
            boolean xlsx = false;
            NodeList overrides = types.getElementsByTagNameNS(CT, "Override");
            for (int i = 0; i < overrides.getLength(); i++) {
                Element e = (Element) overrides.item(i);
                if ("/xl/workbook.xml".equals(e.getAttribute("PartName"))) {
                    xlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"
                            .equals(e.getAttribute("ContentType"));
                }
            }
            if (!xlsx) throw new IOException("仅支持普通 .xlsx，不支持含宏或其他工作簿格式。");
            addContentType(types, imageName, "image/png");
            for (SheetInfo sheet : sheets.values()) addContentType(types, sheet.vml, "application/vnd.openxmlformats-officedocument.vmlDrawing");
            TraceMetadata trace = new TraceMetadata();
            if (identity != null) {
                trace.addProperties(source, types, identity, token);
                for (SheetInfo sheet : sheets.values()) trace.addSheet(source, types, sheet.name, sheet.rels, identity, token);
            }

            EncryptionInfo info = new EncryptionInfo(EncryptionMode.agile, CipherAlgorithm.aes256,
                    HashAlgorithm.sha512, -1, -1, ChainingMode.cbc);
            Encryptor encryptor = info.getEncryptor();
            encryptor.confirmPassword(new String(password));
            Set<String> replaced = new HashSet<>();
            replaced.add("[Content_Types].xml");
            replaced.addAll(trace.parts.keySet());
            for (SheetInfo sheet : sheets.values()) replaced.add(sheet.rels);
            try (OutputStream cipher = encryptor.getDataStream(encrypted);
                 ZipOutputStream zip = new ZipOutputStream(cipher, StandardCharsets.UTF_8)) {
                for (ZipEntry entry : Collections.list(source.entries())) {
                    if (replaced.contains(entry.getName())) continue;
                    zip.putNextEntry(new ZipEntry(entry.getName()));
                    try (InputStream in = source.getInputStream(entry)) {
                        if (sheets.containsKey(entry.getName())) patchSheet(in, zip, sheets.get(entry.getName()), text,
                                trace.newDrawingIds.get(entry.getName()));
                        else in.transferTo(zip);
                    }
                    zip.closeEntry();
                }
                put(zip, "[Content_Types].xml", xmlBytes(types));
                for (var part : trace.parts.entrySet()) put(zip, part.getKey(), xmlBytes(part.getValue()));
                put(zip, imageName, WorkbookProtector.watermarkPng(text.strip(), transparency));
                for (SheetInfo sheet : sheets.values()) {
                    Document rels = trace.sheetRelationships.get(sheet.rels);
                    if (rels == null) rels = source.getEntry(sheet.rels) == null ? newDocument(PR, "Relationships") : readSmallXml(source, sheet.rels);
                    addRelation(rels, sheet.backgroundId, R + "/image", "../media/" + imageName.substring("xl/media/".length()));
                    addRelation(rels, sheet.headerId, R + "/vmlDrawing", "../drawings/" + sheet.vml.substring("xl/drawings/".length()));
                    put(zip, sheet.rels, xmlBytes(rels));
                    put(zip, sheet.vml, WorkbookProtector.vmlXml("wmImage").getBytes(StandardCharsets.UTF_8));
                    Document vmlRels = newDocument(PR, "Relationships");
                    addRelation(vmlRels, "wmImage", R + "/image", "../media/" + imageName.substring("xl/media/".length()));
                    put(zip, sheet.vmlRels, xmlBytes(vmlRels));
                }
            }
            staging = Files.createTempFile(output.getParent(), ".excel-watermark-", ".tmp");
            try (OutputStream out = Files.newOutputStream(staging)) { encrypted.writeFilesystem(out); }
            Files.move(staging, output); // 不覆盖已有文件。
            staging = null;
        } catch (ZipException e) {
            throw new IOException("输入不是有效的未加密 .xlsx；已有打开密码的文件请先解密另存。", e);
        } finally {
            if (staging != null) Files.deleteIfExists(staging);
        }
    }

    private static void patchSheet(InputStream in, OutputStream out, SheetInfo info, String text, String traceDrawingId) throws Exception {
        XMLInputFactory factory = inputFactory();
        XMLEventReader reader = factory.createXMLEventReader(in);
        XMLEventWriter writer = XMLOutputFactory.newFactory().createXMLEventWriter(out, "UTF-8");
        List<Namespace> namespaces = new ArrayList<>();
        LinkedHashMap<String, Element> pending = new LinkedHashMap<>();
        Element margins = newDocument(S, "pageMargins").getDocumentElement();
        margins.setAttribute("left", "0.7"); margins.setAttribute("right", "0.7");
        margins.setAttribute("top", "0.75"); margins.setAttribute("bottom", "0.75");
        margins.setAttribute("header", "0.3"); margins.setAttribute("footer", "0.3");
        pending.put("pageMargins", margins);
        pending.put("headerFooter", newDocument(S, "headerFooter").getDocumentElement());
        if (traceDrawingId != null) {
            Element traceDrawing = newDocument(S, "drawing").getDocumentElement();
            traceDrawing.setAttributeNS(R, "r:id", traceDrawingId);
            pending.put("drawing", traceDrawing);
        }
        Element drawing = newDocument(S, "legacyDrawingHF").getDocumentElement();
        drawing.setAttributeNS(R, "r:id", info.headerId);
        pending.put("legacyDrawingHF", drawing);
        Element picture = newDocument(S, "picture").getDocumentElement();
        picture.setAttributeNS(R, "r:id", info.backgroundId);
        pending.put("picture", picture);
        int depth = 0;
        try {
            while (reader.hasNext()) {
                XMLEvent event = reader.nextEvent();
                if (event.isStartElement()) {
                    StartElement start = event.asStartElement();
                    if (depth == 0) {
                        if (!S.equals(start.getName().getNamespaceURI())) throw new IOException("不支持此工作表 XML 命名空间。");
                        start.getNamespaces().forEachRemaining(n -> namespaces.add((Namespace) n));
                    }
                    if (depth == 1 && S.equals(start.getName().getNamespaceURI())) {
                        String local = start.getName().getLocalPart();
                        if (local.equals("legacyDrawingHF") || local.equals("picture")) {
                            throw new IOException("工作表已有背景或页眉页脚图片，请使用最初导出的文件。");
                        }
                        if (local.equals("drawing") && traceDrawingId != null)
                            throw new IOException("工作表绘图关系不完整，无法安全添加透明水印。");
                        flushBefore(writer, pending, ORDER.indexOf(local), text);
                        if (local.equals("pageMargins") || local.equals("headerFooter")) {
                            Element original = readElement(reader, start, namespaces);
                            pending.remove(local);
                            writeMetadata(writer, local, original, text);
                            continue;
                        }
                    }
                    depth++;
                } else if (event.isEndElement()) {
                    depth--;
                    if (depth == 0) flushBefore(writer, pending, Integer.MAX_VALUE, text);
                }
                writer.add(event);
            }
            writer.flush();
        } finally {
            reader.close(); // writer 不关闭调用方持有的 ZIP 流。
        }
    }

    private static void flushBefore(XMLEventWriter writer, LinkedHashMap<String, Element> pending,
                                    int nextRank, String text) throws Exception {
        Iterator<Map.Entry<String, Element>> iterator = pending.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            if (ORDER.indexOf(entry.getKey()) < nextRank) {
                writeMetadata(writer, entry.getKey(), entry.getValue(), text);
                iterator.remove();
            }
        }
    }

    private static void writeMetadata(XMLEventWriter writer, String name, Element element, String text) throws Exception {
        if (name.equals("headerFooter")) patchHeaderFooter(element, text);
        if (name.equals("pageMargins")) {
            double footer = Math.max(Double.parseDouble(element.getAttribute("footer")), 0.2);
            element.setAttribute("footer", Double.toString(footer));
            element.setAttribute("bottom", Double.toString(Math.max(Double.parseDouble(element.getAttribute("bottom")), footer + 0.4)));
        }
        XMLEventReader fragment = inputFactory().createXMLEventReader(new ByteArrayInputStream(xmlBytes(element)));
        while (fragment.hasNext()) {
            XMLEvent event = fragment.nextEvent();
            if (!event.isStartDocument() && !event.isEndDocument()) writer.add(event);
        }
        fragment.close();
    }

    private static void patchHeaderFooter(Element hf, String text) throws IOException {
        hf.setAttribute("scaleWithDoc", "0");
        List<String> variants = new ArrayList<>(List.of("odd"));
        if (enabled(hf, "differentFirst")) variants.add("first");
        if (enabled(hf, "differentOddEven")) variants.add("even");
        HeaderFooterHelper helper = new HeaderFooterHelper();
        for (String variant : variants) {
            Element header = headerChild(hf, variant + "Header");
            String old = header.getTextContent();
            String center = helper.getCenterSection(old);
            header.setTextContent(helper.setCenterSection(old, "&G" + (center.isEmpty() ? "" : "\n" + center)));
            Element footer = headerChild(hf, variant + "Footer");
            old = footer.getTextContent();
            center = helper.getCenterSection(old);
            String escaped = text.strip().replaceAll("\\R", " ").replace("&", "&&");
            footer.setTextContent(helper.setCenterSection(old, (center.isEmpty() ? "" : center + "\n")
                    + "&\"Arial,Regular\"&8&K666666" + escaped));
            if (header.getTextContent().length() > 255 || footer.getTextContent().length() > 255) {
                throw new IOException("原页眉页脚加水印后超过 255 字符，请缩短水印。");
            }
        }
    }

    private static boolean enabled(Element e, String name) { return Set.of("1", "true").contains(e.getAttribute(name)); }

    private static Element headerChild(Element parent, String name) {
        NodeList matches = parent.getElementsByTagNameNS(S, name);
        if (matches.getLength() > 0) return (Element) matches.item(0);
        List<String> order = List.of("oddHeader", "oddFooter", "evenHeader", "evenFooter", "firstHeader", "firstFooter");
        Element created = parent.getOwnerDocument().createElementNS(S, name);
        for (Node node = parent.getFirstChild(); node != null; node = node.getNextSibling()) {
            if (node instanceof Element e && order.indexOf(e.getLocalName()) > order.indexOf(name)) {
                parent.insertBefore(created, node); return created;
            }
        }
        parent.appendChild(created); return created;
    }

    private static Element readElement(XMLEventReader reader, StartElement start, List<Namespace> namespaces) throws Exception {
        StringWriter buffer = new StringWriter();
        XMLEventWriter writer = XMLOutputFactory.newFactory().createXMLEventWriter(buffer);
        XMLEventFactory events = XMLEventFactory.newFactory();
        List<Namespace> wrapperNamespaces = new ArrayList<>();
        for (Namespace ns : namespaces) if (!ns.isDefaultNamespaceDeclaration()) wrapperNamespaces.add(ns);
        wrapperNamespaces.add(events.createNamespace(S));
        writer.add(events.createStartElement("", S, "wrapper", null, wrapperNamespaces.iterator()));
        writer.add(start);
        int level = 1;
        while (reader.hasNext() && level > 0) {
            XMLEvent event = reader.nextEvent();
            writer.add(event);
            if (event.isStartElement()) level++;
            if (event.isEndElement()) level--;
            if (buffer.getBuffer().length() > 1024 * 1024) throw new IOException("工作表元数据异常过大。");
        }
        writer.add(events.createEndElement("", S, "wrapper"));
        writer.close();
        Document parsed = parse(buffer.toString().getBytes(StandardCharsets.UTF_8));
        return (Element) parsed.getDocumentElement().getFirstChild();
    }

    static XMLInputFactory inputFactory() {
        XMLInputFactory factory = XMLInputFactory.newFactory();
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        factory.setProperty("javax.xml.stream.isSupportingExternalEntities", false);
        return factory;
    }

    private static DocumentBuilderFactory documentFactory() throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        return factory;
    }

    private static Document parse(byte[] xml) throws Exception { return documentFactory().newDocumentBuilder().parse(new ByteArrayInputStream(xml)); }

    static Document newDocument(String ns, String root) throws Exception {
        Document doc = documentFactory().newDocumentBuilder().newDocument();
        doc.appendChild(doc.createElementNS(ns, root)); return doc;
    }

    static Document readSmallXml(ZipFile zip, String name) throws Exception {
        ZipEntry entry = zip.getEntry(name);
        if (entry == null) throw new IOException("文件缺少 " + name);
        if (entry.getSize() > 1024 * 1024) throw new IOException("文件元数据异常过大。");
        try (InputStream in = zip.getInputStream(entry)) { return parse(in.readNBytes(1024 * 1024 + 1)); }
    }

    private static byte[] xmlBytes(Node node) throws Exception {
        TransformerFactory factory = TransformerFactory.newInstance();
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
        Transformer transformer = factory.newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        transformer.transform(new DOMSource(node), new StreamResult(out)); return out.toByteArray();
    }

    static void addContentType(Document doc, String name, String type) {
        NodeList existing = doc.getElementsByTagNameNS(CT, "Override");
        for (int i = 0; i < existing.getLength(); i++) {
            Element item = (Element) existing.item(i);
            if (item.getAttribute("PartName").equals("/" + name)) {
                item.setAttribute("ContentType", type);
                return;
            }
        }
        Element entry = doc.createElementNS(CT, "Override");
        entry.setAttribute("PartName", "/" + name); entry.setAttribute("ContentType", type);
        doc.getDocumentElement().appendChild(entry);
    }

    static void addRelation(Document doc, String id, String type, String target) {
        Element entry = doc.createElementNS(PR, "Relationship");
        entry.setAttribute("Id", id); entry.setAttribute("Type", type); entry.setAttribute("Target", target);
        doc.getDocumentElement().appendChild(entry);
    }

    private static void put(ZipOutputStream zip, String name, byte[] bytes) throws IOException {
        zip.putNextEntry(new ZipEntry(name)); zip.write(bytes); zip.closeEntry();
    }
}
