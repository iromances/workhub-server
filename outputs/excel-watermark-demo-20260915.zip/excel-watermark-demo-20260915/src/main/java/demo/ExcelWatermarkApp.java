package demo;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.concurrent.ExecutionException;

/** 运行 main 后选择文件，所有文件处理均在本机完成。 */
public final class ExcelWatermarkApp {
    private final JFrame frame = new JFrame("Excel 水印与打开密码");
    private final JTextArea watermark = new JTextArea("内部数据 · 禁止外传", 2, 32);
    private final JTextField extractor = new JTextField();
    private final JCheckBox showExtractorWatermark = new JCheckBox("显示水印", true);
    private final JCheckBox hideExtractorWatermark = new JCheckBox("隐藏水印", true);
    private final JCheckBox extractorProperty = new JCheckBox("自定义属性", true);
    private final JTextField approvalNumber = new JTextField();
    private final JCheckBox showApprovalWatermark = new JCheckBox("显示水印", true);
    private final JCheckBox hideApprovalWatermark = new JCheckBox("隐藏水印", true);
    private final JCheckBox approvalProperty = new JCheckBox("自定义属性", true);
    private final JTextField filePath = new JTextField();
    private final JRadioButton automaticPassword = new JRadioButton("自动生成（16 位）", true);
    private final JRadioButton manualPassword = new JRadioButton("手动录入");
    private final JPasswordField passwordInput = new JPasswordField();
    private final JPasswordField passwordConfirmation = new JPasswordField();
    private final JTextField resultPassword = new JTextField();
    private final JButton copyPassword = new JButton("复制密码");
    private final JSpinner transparency = new JSpinner(new SpinnerNumberModel(82, 50, 90, 1));
    private final JButton select = new JButton("选择 .xlsx 文件");
    private final JButton generate = new JButton("生成加密副本");
    private final JLabel status = new JLabel("打印时每页带图片水印和水印文字页脚。");
    private Path input;
    private String completedPassword = "";

    public static void main(String[] args) {
        System.setProperty("log4j2.loggerContextFactory", "org.apache.logging.log4j.simple.SimpleLoggerContextFactory");
        if (GraphicsEnvironment.isHeadless()) {
            System.err.println("请在有桌面的环境运行此工具，或从其他 Java 程序调用 WorkbookProtector.protect。");
            return;
        }
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) { /* 使用 Swing 默认主题。 */ }
            new ExcelWatermarkApp().show();
        });
    }

    private void show() {
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));
        filePath.setEditable(false);
        resultPassword.setEditable(false);
        copyPassword.setEnabled(false);
        watermark.setLineWrap(true);
        watermark.setWrapStyleWord(true);
        JPanel picker = new JPanel(new BorderLayout(8, 0));
        picker.add(filePath, BorderLayout.CENTER);
        picker.add(select, BorderLayout.EAST);
        row(form, 0, "水印文字", new JScrollPane(watermark));
        row(form, 1, "提取人（必填）", identityPanel(extractor, showExtractorWatermark, hideExtractorWatermark, extractorProperty));
        extractor.setToolTipText("显示水印、隐藏水印和自定义属性可分别勾选。");
        showExtractorWatermark.setToolTipText("将提取人加入可见水印和打印页脚。");
        hideExtractorWatermark.setToolTipText("将提取人加入 100% 透明的文字水印，屏幕和打印不可见。");
        extractorProperty.setToolTipText("将提取人写入 Excel 自定义属性。");
        approvalNumber.setToolTipText("显示水印、隐藏水印和自定义属性可分别勾选。");
        showApprovalWatermark.setToolTipText("将审批编号加入可见水印和打印页脚。");
        hideApprovalWatermark.setToolTipText("生成审批编号的完全透明文字水印。");
        approvalProperty.setToolTipText("将审批编号写入 Excel 自定义属性。");
        row(form, 2, "审批编号（必填）", identityPanel(approvalNumber, showApprovalWatermark, hideApprovalWatermark, approvalProperty));
        row(form, 3, "Excel 文件", picker);
        ButtonGroup passwordMode = new ButtonGroup();
        passwordMode.add(automaticPassword);
        passwordMode.add(manualPassword);
        JPanel passwordOptions = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        passwordOptions.add(automaticPassword);
        passwordOptions.add(manualPassword);
        row(form, 4, "密码方式", passwordOptions);
        row(form, 5, "手动密码", passwordInput);
        row(form, 6, "确认密码", passwordConfirmation);
        row(form, 7, "", new JLabel("自动：16 位四类字符混编；手动：8～128 个字符，两次输入一致。"));
        JPanel secretPanel = new JPanel(new BorderLayout(8, 0));
        secretPanel.add(resultPassword, BorderLayout.CENTER);
        secretPanel.add(copyPassword, BorderLayout.EAST);
        row(form, 8, "生成成功后的密码", secretPanel);
        resultPassword.setToolTipText("文件生成成功后显示密码；生成前无法复制。");
        row(form, 9, "透明度（%）", transparency);
        row(form, 10, "", new JLabel("水印按 2 列 × 3 行密集平铺；透明度越大越淡，默认 82%。"));
        row(form, 11, "", generate);
        row(form, 12, "", status);
        automaticPassword.addActionListener(e -> updatePasswordMode());
        manualPassword.addActionListener(e -> updatePasswordMode());
        updatePasswordMode();
        select.addActionListener(e -> chooseInput());
        generate.addActionListener(e -> generate());
        copyPassword.addActionListener(e -> {
            try {
                copyCompletedPassword(Toolkit.getDefaultToolkit().getSystemClipboard(), completedPassword);
                status.setText("密码已复制，请与文件分开发送。");
            } catch (Exception failure) {
                status.setText("复制未完成，请重试或手动选中密码复制。");
                JOptionPane.showMessageDialog(frame,
                        completedPassword.isEmpty() ? "请先生成加密文件，成功后才能复制密码。"
                                : "剪贴板未能确认复制成功。请重试，或选中密码后按 Ctrl+C / ⌘C 复制。",
                        "复制未完成", JOptionPane.WARNING_MESSAGE);
            }
        });
        frame.setContentPane(form);
        frame.setMinimumSize(new Dimension(840, 610));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static JPanel identityPanel(JTextField input, JCheckBox... options) {
        JPanel panel = new JPanel(new BorderLayout(8, 0));
        panel.add(input, BorderLayout.CENTER);
        JPanel toggles = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        for (JCheckBox option : options) toggles.add(option);
        panel.add(toggles, BorderLayout.EAST);
        return panel;
    }

    private static void row(JPanel panel, int row, String label, JComponent component) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = row; c.anchor = GridBagConstraints.NORTHWEST;
        c.insets = new Insets(7, 0, 7, 14);
        panel.add(new JLabel(label), c);
        c.gridx = 1; c.weightx = 1; c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(7, 0, 7, 0);
        panel.add(component, c);
    }

    private JFileChooser chooser() {
        JFileChooser chooser = new JFileChooser(input == null ? null : input.getParent().toFile());
        chooser.setFileFilter(new FileNameExtensionFilter("Excel 工作簿 (*.xlsx)", "xlsx"));
        chooser.setAcceptAllFileFilterUsed(false);
        return chooser;
    }

    private void chooseInput() {
        JFileChooser chooser = chooser();
        if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            input = chooser.getSelectedFile().toPath().toAbsolutePath();
            filePath.setText(input.toString());
            filePath.setToolTipText(input.toString());
        }
    }

    private void generate() {
        boolean automatic = automaticPassword.isSelected();
        char[] secret = automatic ? PasswordGenerator.generate() : passwordInput.getPassword();
        boolean submitted = false;
        try {
            if (!automatic) {
                char[] confirmation = passwordConfirmation.getPassword();
                try { validateManualPassword(secret, confirmation); }
                finally { Arrays.fill(confirmation, '\0'); }
            }
            String text = composeWatermark(watermark.getText(), extractor.getText(), approvalNumber.getText(),
                    showExtractorWatermark.isSelected(), showApprovalWatermark.isSelected());
            var identity = new WorkbookProtector.ExportIdentity(extractor.getText(), approvalNumber.getText(),
                    hideExtractorWatermark.isSelected(), hideApprovalWatermark.isSelected(),
                    extractorProperty.isSelected(), approvalProperty.isSelected());
            if (input == null) throw new IllegalArgumentException("请先选择 Excel 文件。");
            int alpha = (Integer) transparency.getValue();
            WorkbookProtector.validateText(text, secret, alpha);

            JFileChooser save = chooser();
            save.setDialogTitle("另存加密副本");
            String name = input.getFileName().toString().replaceFirst("(?i)\\.xlsx$", "");
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            save.setSelectedFile(input.resolveSibling(name + "_水印加密_" + stamp + ".xlsx").toFile());
            if (save.showSaveDialog(frame) != JFileChooser.APPROVE_OPTION) return;
            Path output = save.getSelectedFile().toPath();
            Path source = input;
            busy(true);
            passwordInput.setText("");
            passwordConfirmation.setText("");
            resultPassword.setText("");
            completedPassword = "";
            copyPassword.setEnabled(false);
            new SwingWorker<String, Void>() {
                protected String doInBackground() throws Exception {
                    return protectAndGetPassword(source, output, text, secret, alpha, identity);
                }
                protected void done() {
                    busy(false);
                    try {
                        completedPassword = get();
                        resultPassword.setText(completedPassword);
                        copyPassword.setEnabled(true);
                        status.setText("已生成加密副本。");
                        JOptionPane.showMessageDialog(frame, "已保存：\n" + output.toAbsolutePath()
                                + "\n\n本次打开密码已显示在主窗口，请复制保存。\n请在 Excel 中打开并检查打印预览。", "完成", JOptionPane.INFORMATION_MESSAGE);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        error("处理被中断，请重新生成。");
                    } catch (ExecutionException e) {
                        Throwable cause = e.getCause();
                        error(cause instanceof OutOfMemoryError ? "内存不足，请拆分数据或增加 -Xmx 参数。"
                                : cause.getMessage() == null ? "文件处理失败，请检查文件格式。" : cause.getMessage());
                    } finally { Arrays.fill(secret, '\0'); }
                }
            }.execute();
            submitted = true;
        } catch (Exception e) {
            busy(false);
            error(e.getMessage());
        } finally {
            if (!submitted) Arrays.fill(secret, '\0');
        }
    }

    static String protectAndGetPassword(Path source, Path output, String text, char[] secret, int alpha) throws Exception {
        return protectAndGetPassword(source, output, text, secret, alpha, null);
    }

    static String protectAndGetPassword(Path source, Path output, String text, char[] secret, int alpha,
                                       WorkbookProtector.ExportIdentity identity) throws Exception {
        try {
            WorkbookProtector.protect(source, output, text, secret, alpha, identity);
            return new String(secret);
        } finally {
            Arrays.fill(secret, '\0');
        }
    }

    static void copyCompletedPassword(Clipboard clipboard, String password) throws Exception {
        if (password == null || password.isBlank() || password.indexOf('\0') >= 0)
            throw new IllegalStateException("没有可复制的有效密码。");
        clipboard.setContents(new StringSelection(password), null);
        if (!password.equals(clipboard.getData(DataFlavor.stringFlavor)))
            throw new IllegalStateException("剪贴板内容与密码不一致。");
    }

    private void updatePasswordMode() {
        boolean manual = manualPassword.isSelected();
        passwordInput.setEnabled(manual);
        passwordConfirmation.setEnabled(manual);
        if (!manual) {
            passwordInput.setText("");
            passwordConfirmation.setText("");
        }
    }

    static void validateManualPassword(char[] password, char[] confirmation) {
        WorkbookProtector.validatePassword(password);
        if (!Arrays.equals(password, confirmation))
            throw new IllegalArgumentException("两次输入的密码不一致，请重新确认。");
    }

    static String composeWatermark(String watermark, String extractor, String approvalNumber) {
        return composeWatermark(watermark, extractor, approvalNumber, true);
    }

    static String composeWatermark(String watermark, String extractor, String approvalNumber, boolean showExtractor) {
        return composeWatermark(watermark, extractor, approvalNumber, showExtractor, true);
    }

    static String composeWatermark(String watermark, String extractor, String approvalNumber,
                                   boolean showExtractor, boolean showApproval) {
        String name = requiredField(extractor, "提取人");
        String number = requiredField(approvalNumber, "审批编号");
        String text = watermark.strip();
        if (text.isEmpty()) throw new IllegalArgumentException("请输入水印文字。");
        int maxLines = 4 - (showExtractor ? 1 : 0) - (showApproval ? 1 : 0);
        if (text.lines().count() > maxLines)
            throw new IllegalArgumentException("当前设置下水印文字最多 " + maxLines + " 行，合并后最多 4 行。");
        return text + (showExtractor ? "\n" + name : "") + (showApproval ? "\n" + number : "");
    }

    private static String requiredField(String value, String label) {
        String text = value.strip();
        if (text.isEmpty()) throw new IllegalArgumentException("请填写" + label + "。");
        if (text.codePoints().anyMatch(Character::isISOControl))
            throw new IllegalArgumentException(label + "不能包含换行或控制字符。");
        return text;
    }

    private void busy(boolean busy) {
        select.setEnabled(!busy);
        generate.setEnabled(!busy);
        watermark.setEnabled(!busy);
        extractor.setEnabled(!busy);
        showExtractorWatermark.setEnabled(!busy);
        hideExtractorWatermark.setEnabled(!busy);
        extractorProperty.setEnabled(!busy);
        approvalNumber.setEnabled(!busy);
        showApprovalWatermark.setEnabled(!busy);
        hideApprovalWatermark.setEnabled(!busy);
        approvalProperty.setEnabled(!busy);
        automaticPassword.setEnabled(!busy);
        manualPassword.setEnabled(!busy);
        passwordInput.setEnabled(!busy && manualPassword.isSelected());
        passwordConfirmation.setEnabled(!busy && manualPassword.isSelected());
        copyPassword.setEnabled(!busy && !completedPassword.isEmpty());
        transparency.setEnabled(!busy);
        frame.setDefaultCloseOperation(busy ? WindowConstants.DO_NOTHING_ON_CLOSE : WindowConstants.EXIT_ON_CLOSE);
        status.setText(busy ? "正在添加水印并加密，请稍候……" : "打印时每页带图片水印和水印文字页脚。");
    }

    private void error(String message) {
        status.setText("未生成文件。");
        JOptionPane.showMessageDialog(frame, message, "请检查", JOptionPane.ERROR_MESSAGE);
    }
}
